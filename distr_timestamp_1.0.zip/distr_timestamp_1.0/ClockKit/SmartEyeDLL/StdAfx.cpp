/**********************************************
* $Id: StdAfx.cpp,v 1.1 2003/11/26 00:25:49 kowitz Exp $
*
* $Log: StdAfx.cpp,v $
* Revision 1.1  2003/11/26 00:25:49  kowitz
* SmartEye DLL project for providing timing information to Smart Eye Pro
*
* Revision 1.2  2003/10/17 10:57:03  pers
* added standard Smart Eye CVS headers
*
**********************************************
* (C) Copyright 2003 Smart Eye AB
**********************************************/

// stdafx.cpp : source file that includes just the standard includes
//	TimeService.pch will be the pre-compiled header
//	stdafx.obj will contain the pre-compiled type information

#include "stdafx.h"

// TODO: reference any additional headers you need in STDAFX.H
// and not in this file
