required libraries:
commonc++

build tools:
doxygen
graphviz
swig

