#ifndef DEX_COMMON_H
#define DEX_COMMON_H

#include "Timestamp.h"

// note, this is in a different location on linux, bsd
// the endian values prob. need to be defined on windows.
//#include <endian.h>
// now we're using the endian stuff figured out by commoncpp in <cc++/config.h>
    
#endif //DEX_COMMON_H
